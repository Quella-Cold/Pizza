/******************************************************
** Program: main.cpp
** Author: Youli Zhao
** Date: 10/13/2018
** Description:
** Input:
** Output:
******************************************************/
#include "./pizza.h"
#include "./menu.h"
#include "./restaurant.h"
// #include "./employee.h"
#include "./hours.h"
#include "./order.h"

int main(){
	Restaurant R;
	R.choice_menu();


	return 0;
}