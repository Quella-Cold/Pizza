/******************************************************
** Program: employee.h
** Author: Youli Zhao
** Date: 10/13/2018
** Description:
** Input:
** Output:
******************************************************/
#ifndef employee_h
#define emoloyee_h
#include<string>

using namespace std;

struct employee{
	string id;
	string first_name;
	string last_name;
	string password;
};

#endif
