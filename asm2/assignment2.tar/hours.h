/******************************************************
** Program: hours.h
** Author: Youli Zhao
** Date: 10/13/2018
** Description:
** Input:
** Output:
******************************************************/
#ifndef hours_h
#define hours_h
#include<string>

using namespace std;

struct hours{
	string day;
	string open_hour;
	string close_hour;
};

#endif
